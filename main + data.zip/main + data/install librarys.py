import os
os.system("pip install --upgrade pip")
os.system("pip3 install tkinter")
os.system("pip3 install pandas")
os.system("pip3 install cProfile")
os.system("pip3 install operator")